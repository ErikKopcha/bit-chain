--
-- PostgreSQL database dump
--

-- Dumped from database version 14.17 (Homebrew)
-- Dumped by pg_dump version 14.17 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: TradeCategory; Type: TYPE; Schema: public; Owner: dx
--

CREATE TYPE public."TradeCategory" AS ENUM (
    'solo',
    'radar',
    'everest',
    'cryptonite_radar',
    'cryptonite_everest',
    'humster'
);


ALTER TYPE public."TradeCategory" OWNER TO dx;

--
-- Name: TradeResult; Type: TYPE; Schema: public; Owner: dx
--

CREATE TYPE public."TradeResult" AS ENUM (
    'WIN',
    'LOSS',
    'PENDING'
);


ALTER TYPE public."TradeResult" OWNER TO dx;

--
-- Name: TradeSide; Type: TYPE; Schema: public; Owner: dx
--

CREATE TYPE public."TradeSide" AS ENUM (
    'LONG',
    'SHORT'
);


ALTER TYPE public."TradeSide" OWNER TO dx;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Trade; Type: TABLE; Schema: public; Owner: dx
--

CREATE TABLE public."Trade" (
    id text NOT NULL,
    "userId" text NOT NULL,
    date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    symbol text NOT NULL,
    side public."TradeSide" NOT NULL,
    "entryPrice" double precision NOT NULL,
    "positionSize" double precision NOT NULL,
    "stopLoss" double precision NOT NULL,
    "exitPrice" double precision NOT NULL,
    commission double precision NOT NULL,
    "riskPercent" double precision NOT NULL,
    pnl double precision NOT NULL,
    result public."TradeResult" NOT NULL,
    leverage double precision,
    investment double precision,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    category public."TradeCategory" NOT NULL,
    deposit double precision DEFAULT 500 NOT NULL
);


ALTER TABLE public."Trade" OWNER TO dx;

--
-- Name: User; Type: TABLE; Schema: public; Owner: dx
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."User" OWNER TO dx;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: dx
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO dx;

--
-- Data for Name: Trade; Type: TABLE DATA; Schema: public; Owner: dx
--

COPY public."Trade" (id, "userId", date, symbol, side, "entryPrice", "positionSize", "stopLoss", "exitPrice", commission, "riskPercent", pnl, result, leverage, investment, "createdAt", category, deposit) FROM stdin;
cma40y7ku000dchxgzacmcg4f	cm9n7u7hd0000chn8ps5ik8sb	2025-04-30 14:21:24.614	1	LONG	1	1	0	0	0	0	0	PENDING	1	1	2025-04-30 14:21:34.303	solo	500
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: dx
--

COPY public."User" (id, email, password, "createdAt") FROM stdin;
cm9n7u7hd0000chn8ps5ik8sb	erickopcha@gmail.com	$2b$12$Yj7U70t5gbzCnsiJsEnUxOQUq8h01duMed6bhXGJYvft1Y6F/6awy	2025-04-18 20:02:19.861
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: dx
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
4d002d18-f460-4194-b177-f53c54595452	7b20b168971867b09bcb6378938658fff54a0db33b2bfe86866bbcfc05d48ad8	2025-04-16 20:27:31.967532+01	20250416192731_init	\N	\N	2025-04-16 20:27:31.743979+01	1
3cdca888-8542-40f3-8d2e-278b9e50c184	dcb4e4479fef67e7f7d4aa84bf0d4aab822c9e0de11467421b5091eb9f04af35	2025-04-29 17:41:22.821777+01	20250429164122_add_category_to_trade	\N	\N	2025-04-29 17:41:22.591213+01	1
\.


--
-- Name: Trade Trade_pkey; Type: CONSTRAINT; Schema: public; Owner: dx
--

ALTER TABLE ONLY public."Trade"
    ADD CONSTRAINT "Trade_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: dx
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: dx
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: dx
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: Trade Trade_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dx
--

ALTER TABLE ONLY public."Trade"
    ADD CONSTRAINT "Trade_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

